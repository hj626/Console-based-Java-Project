package shop.product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import shop.db.DBConn;
import shop.review.ReviewDAO;
import shop.review.ReviewDTO;

public class ProductDAO {

	public int insertProduct(ProductDTO dto)  {
        
		int result = 0;

        Connection conn = DBConn.getConnection(); 
        PreparedStatement pstmt = null;
        String sql;

        try {
            sql = "INSERT INTO PRODUCT (product_id, name, description, stock, reg_date, price) ";
            sql += "VALUES (PRODUCT_SEQ.NEXTVAL, ?, ?, ?, ?, ?)";

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, dto.getName());
            pstmt.setString(2, dto.getDescription());
            pstmt.setInt(3, dto.getStock());
            pstmt.setDate(4, new java.sql.Date(dto.getReg_date().getTime()));
            pstmt.setInt(5, dto.getPrice());

            result = pstmt.executeUpdate();
            pstmt.close();

        } catch (Exception e) {
            System.out.println("insertProduct ����: " + e.toString());
        }

        return result;
    }
	
	//--��ǰ��� ������ ID���� ��ȣ ����
	public int getMaxProductID() {
		int maxId = 0;
		  
		String sql = "select NVL(MAX(product_id), 0) From product";
		
		try( Connection conn = DBConn.getConnection(); 
		        PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery()){

			if(rs.next()) {
				maxId = rs.getInt(1);
			}
		}catch (Exception e) {
		     e.printStackTrace();
		     }
		return maxId;
	}
			
//----��ǰ����			
	 public int updateProduct(ProductDTO dto, int fieldNum)  {
	        int result = 0;
	        String sql = null;
	        switch (fieldNum) {
	        
	        case 1: 
	        	sql = "UPDATE PRODUCT SET name = ? WHERE product_id = ?"; break;
	        case 2: 
	        	sql = "UPDATE PRODUCT SET description = ? WHERE product_id = ?"; break;
	        case 3: 
	        	sql = "UPDATE PRODUCT SET stock = ? WHERE product_id = ?"; break;
	        case 4: 
	        	sql = "UPDATE PRODUCT SET price = ? WHERE product_id = ?"; break;
	        	default: System.out.println("�߸��� �����׸��Դϴ�."); return 0;
	        }
	        
	        try(  Connection conn = DBConn.getConnection();
	    	  PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        	
	        	switch (fieldNum) {
				case 1:
					pstmt.setString(1, dto.getName());	break;
				case 2:
					pstmt.setString(1, dto.getDescription());	break;
				case 3:
					pstmt.setInt(1, dto.getStock());	break;
				case 4:
						pstmt.setInt(1, dto.getPrice());	break;
	        	}
	        	pstmt.setInt(2, dto.getProduct_id());
	        	result = pstmt.executeUpdate();
				
	        } catch (Exception e) {
	            System.out.println("updateProduct ����: " + e.toString());
	        }

	        return result;
	    }
//--------

	
	 public int deleteProduct(int product_id) { 
	        int result = 0;

	        Connection conn = DBConn.getConnection();
	        PreparedStatement pstmt = null;
	        String sql;

	        try {
	            sql = "DELETE FROM PRODUCT WHERE product_id=?";
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, product_id);

	            result = pstmt.executeUpdate();
	            pstmt.close();

	        } catch (Exception e) {
	            System.out.println("deleteProduct ����: " + e.toString());
	        }

	        return result;
	    }

	    // 4. ��ǰ ��ü ��ȸ
	    public List<ProductDTO> getAllProducts() {
	    	
	        List<ProductDTO> list = new ArrayList<>();

//	        Connection conn = DBConn.getConnection();
	        
	        Connection conn = DBConn.getConnection();//
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	        String sql;

	        try {
	        	sql = "SELECT P.product_id, P.name, P.description, P.stock, P.price, P.reg_date, ";
	        	sql += "NVL(D.discount_rate, 0) AS discount_rate ";
	        	sql += "FROM PRODUCT P LEFT JOIN DISCOUNT D ON P.product_id = D.product_id ";
	        	sql += "ORDER BY P.product_id ASC"; 
	            
	            pstmt = conn.prepareStatement(sql);
	            rs = pstmt.executeQuery();

	            while (rs.next()) {
	                ProductDTO dto = new ProductDTO();

	                dto.setProduct_id(rs.getInt("product_id"));
	                dto.setName(rs.getString("name"));
	                dto.setDescription(rs.getString("description"));
	                dto.setStock(rs.getInt("stock"));
	                dto.setPrice(rs.getInt("price"));		//��.�߰�
	                dto.setReg_date(rs.getDate("reg_date"));

	                int discountRate = rs.getInt("discount_rate");
	                dto.setDiscountRate(discountRate);
	                
	                int discountedPrice = (int)(dto.getPrice() * (100 - discountRate) / 100.0);
	                dto.setDiscountedPrice(discountedPrice);
	                
	                list.add(dto);
	            }

	            rs.close();
	            pstmt.close();

	        } catch (Exception e) {
	            System.out.println("getAllProducts ����: " + e.toString());
	        }

	        return list;
	    }

	    // 5. ��ǰ �ϳ��� �˻� (��ǰ��ȣ��)
	    public ProductDTO getProductById(int product_id) {
	        ProductDTO dto = null;
	  
	        String sql;

	        try {
	            Connection conn = DBConn.getConnection();
		        PreparedStatement pstmt = null;
		        ResultSet rs = null;
	        	
	        	//��.sql�� ����
		        sql = "SELECT P.product_id, P.name, P.description, P.stock, P.price, P.reg_date, " ;
		        sql += "NVL(D.discount_rate, 0) AS discount_rate ";
		        sql += "FROM PRODUCT P LEFT JOIN DISCOUNT D ";
		        sql += "ON P.product_id = D.product_id where P.product_id = ?";

	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, product_id);

	            rs = pstmt.executeQuery();

	            if (rs.next()) {
	                dto = new ProductDTO();

	                dto.setProduct_id(rs.getInt("product_id"));
	                dto.setName(rs.getString("name"));
	                dto.setDescription(rs.getString("description"));
	                dto.setStock(rs.getInt("stock"));
	                dto.setPrice(rs.getInt("price"));	//��.�߰�
	                dto.setReg_date(rs.getDate("reg_date"));
	                dto.setDiscountRate(rs.getInt("discount_rate"));	//��.�߰�
	                int discountedPrice = (int) (dto.getPrice() * ((100 - dto.getDiscountRate()) / 100.0));		//��.�߰�
	                dto.setDiscountedPrice(discountedPrice);		//��.�߰�
	            }

	            rs.close();
	            pstmt.close();

	        } catch (Exception e) {
	            System.out.println("getProductById ����: " + e.toString());
	        }

	        return dto;
	    }
	    
	    public List<ProductDTO> getDiscountedProductList() {
	        List<ProductDTO> list = new ArrayList<>();

	        Connection conn = DBConn.getConnection();
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;

	        String sql = "SELECT P.product_id, P.name, P.description, P.stock, P.reg_date, P.price, " ;
	        sql += "NVL(D.discount_rate, 0) AS discount_rate ";
	        sql += "FROM PRODUCT P LEFT JOIN DISCOUNT D ";
	        sql += "ON P.product_id = D.product_id";

	        try {
	            pstmt = conn.prepareStatement(sql);
	            rs = pstmt.executeQuery();

	            while (rs.next()) {
	                ProductDTO dto = new ProductDTO();

	                dto.setProduct_id(rs.getInt("product_id"));
	                dto.setName(rs.getString("name"));
	                dto.setDescription(rs.getString("description"));
	                dto.setStock(rs.getInt("stock"));
	                dto.setReg_date(rs.getDate("reg_date"));
	                dto.setPrice(rs.getInt("price"));
	                dto.setDiscountRate(rs.getInt("discount_rate"));  // ������ �߰�
	                int discountedPrice = (int) (dto.getPrice() * ((100 - dto.getDiscountRate()) / 100.0));
	                dto.setDiscountedPrice(discountedPrice);
	                
	                
	                list.add(dto);
	            }

	            rs.close();
	            pstmt.close();

	        } catch (Exception e) {
	            System.out.println(e.toString());
	        }

	        return list;
	    }
	    
	 // ��ǰ�� Ű����� �˻�
	    public List<ProductDTO> searchProductsByName(String keyword) {
	        List<ProductDTO> list = new ArrayList<>();
	        Connection conn = DBConn.getConnection();
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;

	        String sql = "SELECT P.product_id, P.name, P.description, P.stock, P.price, P.reg_date, "
	                   + "NVL(D.discount_rate, 0) AS discount_rate "
	                   + "FROM PRODUCT P LEFT JOIN DISCOUNT D "
	                   + "ON P.product_id = D.product_id "
	                   + "WHERE P.name LIKE ?";

	        try {
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setString(1, "%" + keyword + "%"); // �κ� �˻�
	            rs = pstmt.executeQuery();

	            while (rs.next()) {
	                ProductDTO dto = new ProductDTO();
	                dto.setProduct_id(rs.getInt("product_id"));
	                dto.setName(rs.getString("name"));
	                dto.setDescription(rs.getString("description"));
	                dto.setStock(rs.getInt("stock"));
	                dto.setPrice(rs.getInt("price"));
	                dto.setReg_date(rs.getDate("reg_date"));
	                dto.setDiscountRate(rs.getInt("discount_rate"));
	                int discountedPrice = (int) (dto.getPrice() * ((100 - dto.getDiscountRate()) / 100.0));
	                dto.setDiscountedPrice(discountedPrice);
	                list.add(dto);
	            }

	            rs.close();
	            pstmt.close();
	        } catch (Exception e) {
	            System.out.println("searchProductsByName ����: " + e.toString());
	        }

	        return list;
	    }
	    // ǰ���ӹ� ��� �߰� 
	    public List<ProductDTO> getRowStock() {
	    	
	    	List<ProductDTO> list = new ArrayList<ProductDTO>();
	    	Connection conn = DBConn.getConnection();
	    	
	    	PreparedStatement psmtm = null;
	    	ResultSet rs =  null;
	    	
	    	 String sql = "SELECT P.product_id, P.name, P.description, P.stock, P.reg_date," ;
	    	        sql += "NVL(P.price, 0) AS price, ";       
	    	        sql += "NVL(D.discount_rate, 0) AS discount_rate ";
		            sql += "FROM PRODUCT P LEFT JOIN DISCOUNT D ";
		            sql += "ON P.product_id = D.product_id ";
		            sql += "WHERE P.stock <= 3 and P.stock >0 "; //3�� ���Ϸ� ����� ������ �� 
	    	
		            
		            try {
						
		            	psmtm = conn.prepareStatement(sql);
		            	rs = psmtm.executeQuery();
		            	
		            	while (rs.next()) {
		            		
		            		ProductDTO dto = new ProductDTO();
		            		
		            		dto.setProduct_id(rs.getInt("product_id"));
		            		dto.setName(rs.getString("name"));
		            		dto.setDescription(rs.getString("description"));
		            		dto.setStock(rs.getInt("stock"));
		            		dto.setPrice(rs.getInt("price"));
		            		dto.setReg_date(rs.getDate("reg_date"));
		            		dto.setDiscountRate(rs.getInt("discount_rate")); 
		            		int discountedPrice = (int) (dto.getPrice() * ((100 - dto.getDiscountRate()) / 100.0));
			                dto.setDiscountedPrice(discountedPrice);
			                list.add(dto);
		            		
		            		
			              
		            	}
		            	  rs.close();
				          psmtm.close();
		            	
					} catch (Exception e) {
						System.out.println("�����߻�"+ e.toString());
					}
					return list;
	    	
	    }
	    
	 // ��ǰ ��ȸ�ϸ� ���� ���̰� �ϴ� �޼��� �߰��߽��ϴ�.----

		public Map<String, Object> getProductWithReviews(int productId) {
			Map<String, Object> resultMap = new HashMap<>();

			// ������ getProductById �޼��带 ȣ���� ��ǰ ��ȸ
			ProductDTO product = getProductById(productId);

			// ReviewDAO ��ü ���� �� ���� ��ȸ �޼��� ȣ��
			ReviewDAO reviewDAO = new ReviewDAO();
			List<ReviewDTO> reviews = reviewDAO.getReviewsByProductId(productId);

			// ��ȸ�� ��ǰ�� ���� ����Ʈ�� Map�� �����Ͽ� ��ȯ
			resultMap.put("product", product);
			resultMap.put("reviews", reviews);

			return resultMap;
		}

		// �������---------
	}

