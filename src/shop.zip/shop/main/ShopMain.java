package shop.main;

import java.util.Scanner;

import shop.discount.Discount;
import shop.discount.DiscountMain;
import shop.member.MemberMain;
import shop.product.Product;
import shop.review.ReviewMain;

public class ShopMain {

	public static void main(String[] args) {	
		
		Scanner sc = new Scanner(System.in);
		int ch1, ch2;
		
		Discount ob = new Discount();
		
		while (true) {
			do {
				printMainMenu();
				System.out.println();
				System.out.print("����: ");
                
//				System.out.print("1.ȸ������ 2.��ǰ���� 3.������� 4.���ΰ��� 0.����");
				ch1 = sc.nextInt();
				
//				clearConsole();
			} while(ch1<0||ch1>4);
			
			switch (ch1) {
			case 1:
				MemberMain.run();
				break;
			case 2:
				Product.run();
				break;
			case 3:
				ReviewMain.run();
				break;
			case 4:
				DiscountMain.run();
				break;
			default:
				System.exit(0);
				break;
			}
		}
	
	}

	//console â ����(�� ��ó�� ���̰� �ϱ�)
//	public static void clearConsole() {
//	    for (int i = 0; i < 50; i++) {
//	        System.out.println();
//	    }
//	}

	
	
//	public static void printMainMenu() {
//	    final String[] art = {
//	        "       @@@@@@@@@@@@&                                                             ",
//	        "     /@@(         &@@.                                                           ",
//	        "      @@@@@@@@@@.  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&      ",
//	        "              @@@   @@@                                                 @@@     ",
//	        "               @@@   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@     ",
//	        "               ,@@&  #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@      ",
//	        "                @@@*  @@@                                            .@@@        ",
//	        "                 @@@   @@@  @@@@@#  *@@@@@@@   @@@@@@@,  &@@@@@*     @@@         ",
//	        "                  @@@  .@@&                                        .@@@          ",
//	        "                  ,@@&  %@@/ .@@@@*  #@@@@@@   @@@@@@#  (@@@@&    ,@@@           ",
//	        "                   &@@*  @@@                                     .@@@            ",
//	        "                    @@@   @@@                                   .@@@             ",
//	        "                     @@@   &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@/              ",
//	        "                     ,@@@                                                        ",
//	        "                      #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                 ",
//	        "                         .****,,**********************,****,***.                 ",
//	        "                          @@@@@@@@.                  @@@@@@@@%                   ",
//	        "                         @@@    @@@.                @@@     @@%                  ",
//	        "                         @@@%  (@@@                 *@@@   @@@.                  ",
//	        "                           @@@@@@                     /@@@@@,                   ",
//	        "                                                                                 "
//	    };
//
//	    final int maxShift = 30;  // ���������� �̵��� �ִ� ĭ ��
//	    final int delay = 50;     // �и� ������ ��� �ð� (ms)
//
//	    Thread moveThread = new Thread(new Runnable() {
//	        public void run() {
//	            for (int shift = 0; shift <= maxShift; shift++) {
//	                clearConsole(); // ���� ��� ����� ȿ��
//	                for (int i = 0; i < art.length; i++) {
//	                    System.out.println(spaces(shift) + art[i]);
//	                }
//
//	                // �޴��� �� ���� ��� (���� ��ġ)
//	                if (shift == maxShift) {
//	                    System.out.println("\n===========================================");
//	                    System.out.println("         WELCOME TO SHOPPING MALL ");
//	                    System.out.println("===========================================\n");
//	                    System.out.println("  [1] ȸ�� ����");
//	                    System.out.println("  [2] ��ǰ ����");
//	                    System.out.println("  [3] ���� ����");
//	                    System.out.println("  [4] ���� ����");
//	                    System.out.println("  [0] ����");
//	                }
//
//	                try {
//	                    Thread.sleep(delay);
//	                } catch (InterruptedException e) {
//	                    System.out.println("��� �� ���ͷ�Ʈ �߻�");
//	                }
//	            }
//	        }
//	    });
//
//	    moveThread.start();
//	    try {
//	        moveThread.join(); // ��� ���� ������ ���
//	    } catch (InterruptedException e) {
//	        System.out.println("���� ������ ���ͷ�Ʈ");
//	    }
//	}
//
//	// ���� ���� �Լ�
//	private static String spaces(int count) {
//	    StringBuilder sb = new StringBuilder();
//	    for (int i = 0; i < count; i++) {
//	        sb.append(' ');
//	    }
//	    return sb.toString();
//	}
//
//	// �ܼ� �ʱ�ȭ �䳻 (�ٹٲ����� ����)
//	private static void clearConsole() {
//	    for (int i = 0; i < 50; i++) {
//	        System.out.println();
//	    }
//	}


	
//	public static void printMainMenu() {
//        System.out.println("\n===========================================");
//        System.out.println("         WELCOME TO SHOPPING MALL ");
//        System.out.println("===========================================");
//        System.out.println();
//        System.out.println("  [1] ȸ�� ����");
//        System.out.println("  [2] ��ǰ ����");
//        System.out.println("  [3] ���� ����");
//        System.out.println("  [4] ���� ����");
//        System.out.println("  [0] ����");
//        
//	}

	public static void printMainMenu() {
	    String[] lines = {
	        "\n===========================================",
	        "         WELCOME TO SHOPPING MALL ",
	        "===========================================",
	        "",
	        "  [1] ȸ�� ����",
	        "  [2] ��ǰ ����",
	        "  [3] ���� ����",
	        "  [4] ���� ����",
	        "  [0] ����"
	    };

	    for (String line : lines) {
	        print1(line);
	    }
	}

	// �� ���ھ� ����ϴ� �޼���
	public static void print1(String text) {
		
	    for (char ch : text.toCharArray()) {
	        System.out.print(ch);
	        try {
	            Thread.sleep(10); 
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	    System.out.println();
	}

}
