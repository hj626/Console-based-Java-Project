package shop.main;

import java.util.Scanner;

import shop.discount.Discount;
import shop.discount.DiscountMain;
import shop.member.MemberMain;
import shop.product.Product;
import shop.review.ReviewMain;

public class ShopMain {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int ch1, ch2;
		
		Discount ob = new Discount();
		
		while (true) {
			do {
				printMainMenu();
				System.out.print("����: ");
                
//				System.out.print("1.ȸ������ 2.��ǰ���� 3.������� 4.���ΰ��� 0.����");
				ch1 = sc.nextInt();
			} while(ch1<0||ch1>4);
			
			switch (ch1) {
			case 1:
				MemberMain.run();
				break;
			case 2:
				Product.run();
				break;
			case 3:
				ReviewMain.run();
				break;
			case 4:
				DiscountMain.run();
				break;
			default:
				System.exit(0);
				break;
			}
		}
		
		
	}
	
	public static void printMainMenu() {
        System.out.println("\n===========================================");
        System.out.println("         WELCOME TO SHOPPING MALL ");
        System.out.println("===========================================");
        System.out.println();
        System.out.println("  [1] ȸ�� ����");
        System.out.println("  [2] ��ǰ ����");
        System.out.println("  [3] ���� ����");
        System.out.println("  [4] ���� ����");
        System.out.println("  [0] ����");
        
	}

}
