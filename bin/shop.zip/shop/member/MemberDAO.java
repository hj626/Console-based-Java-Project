package shop.member;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import shop.db.DBConn;

public class MemberDAO {
	//--�μ�Ʈ - ȸ���߰�
	//- ȸ�� ��� ����
	//-	 ȸ��Ż��
	//-	 "ȸ���˻� : ȸ������, ���Ż�ǰ"

	public int insertData(MemberDTO dto) {

		int result=0;
		Connection conn = DBConn.getConnection();
		PreparedStatement pstmt = null;

		String sql;

		try {
			sql = "INSERT INTO MEMBER VALUES (?,?, ?,?,SYSDATE)";
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPw());		
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getTel());

			result = pstmt.executeUpdate();
			pstmt.close();

		} catch (Exception e) {
			//System.out.println(e.toString());
		}
		return result;
	}
	//-------	
	public int updateData(MemberDTO dto) {

		int result = 0;
		Connection conn = DBConn.getConnection();
		PreparedStatement pstmt = null;

		String sql;

		try {
			sql = "UPDATE member SET PW=?, TEL=? where ID=?";
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, dto.getPw());
			pstmt.setString(2, dto.getTel());
			pstmt.setString(3, dto.getId());

			result = pstmt.executeUpdate();
			pstmt.close();

		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return result;	
	}

	//------����Ʈ
	public MemberDTO selectData(String id) {

		MemberDTO dto = new MemberDTO();
		Connection conn = DBConn.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;

		String sql;
try {
		sql = "SELECT * FROM MEMBER WHERE ID=?";
		pstmt = conn.prepareStatement(sql);
		
		pstmt.setString(1, id);

		rs = pstmt.executeQuery();
		while(rs.next()) {
			dto = new MemberDTO();
			
			dto.setId(rs.getString("id"));
			dto.setPw(rs.getString("pw"));
			dto.setName(rs.getString("name"));
			dto.setTel(rs.getString("tel"));
			dto.setReg_date(rs.getDate("reg_date"));
		}
		rs.close();
		pstmt.close();
		
	} catch (Exception e) {
		System.out.println(e.toString());	
		
	}return dto ;
	}

//------����Ʈ
	public int deleteData(String id) {
		
		int result = 0;
		Connection conn = DBConn.getConnection();
		PreparedStatement pstmt = null;
		String sql;

		try {
			sql = "DELETE FROM MEMBER WHERE ID=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			
			result = pstmt.executeUpdate();
			pstmt.close();			

		} catch (Exception e) {
			System.out.println(e.toString());	
		}
		return result;
	}
}