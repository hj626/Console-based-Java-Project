package shop.product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import shop.db.DBConn;

public class ProductDAO {

	public int insertProduct(ProductDTO dto)  {
        
		int result = 0;

        Connection conn = DBConn.getConnection(); 
        PreparedStatement pstmt = null;
        String sql;

        try {
            sql = "INSERT INTO PRODUCT (product_id, name, description, stock, reg_date, price) ";
            sql += "VALUES (?, ?, ?, ?, ?,?)";

            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, dto.getProduct_id());
            pstmt.setString(2, dto.getName());
            pstmt.setString(3, dto.getDescription());
            pstmt.setInt(4, dto.getStock());
            pstmt.setDate(5, new java.sql.Date(dto.getReg_date().getTime()));
            pstmt.setInt(6, dto.getPrice());
            
            result = pstmt.executeUpdate();
            pstmt.close();

        } catch (Exception e) {
            System.out.println("insertProduct ����: " + e.toString());
        }

        return result;
    }
	
	
	 public int updateProduct(ProductDTO dto)  {
	        int result = 0;

	        Connection conn = DBConn.getConnection();
	        PreparedStatement pstmt = null;
	        String sql;

	        try {
	            sql = "UPDATE PRODUCT SET name=?, description=?, stock=?, price=? ";
	            sql += "WHERE product_id=?";

	            pstmt = conn.prepareStatement(sql); 
	            pstmt.setString(1, dto.getName());
	            pstmt.setString(2, dto.getDescription());
	            pstmt.setInt(3, dto.getStock());
	            pstmt.setInt(4, dto.getPrice());
	            pstmt.setInt(5, dto.getProduct_id());

	            result = pstmt.executeUpdate();
	            pstmt.close();

	        } catch (Exception e) {
	            System.out.println("updateProduct ����: " + e.toString());
	        }

	        return result;
	    }
	
	 public int deleteProduct(int product_id) { 
	        int result = 0;

	        Connection conn = DBConn.getConnection();
	        PreparedStatement pstmt = null;
	        String sql;

	        try {
	            sql = "DELETE FROM PRODUCT WHERE product_id=?";
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, product_id);

	            result = pstmt.executeUpdate();
	            pstmt.close();

	        } catch (Exception e) {
	            System.out.println("deleteProduct ����: " + e.toString());
	        }

	        return result;
	    }

	    // 4. ��ǰ ��ü ��ȸ
	    public List<ProductDTO> getAllProducts() {
	    	
	        List<ProductDTO> list = new ArrayList<>();

//	        Connection conn = DBConn.getConnection();
	        
	        Connection conn = DBConn.getConnection();//
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	        String sql;

	        try {
	            sql = "SELECT product_id, name, description, stock, price, reg_date FROM PRODUCT";		//��.price �߰�
	            pstmt = conn.prepareStatement(sql);
	            rs = pstmt.executeQuery();

	            while (rs.next()) {
	                ProductDTO dto = new ProductDTO();

	                dto.setProduct_id(rs.getInt("product_id"));
	                dto.setName(rs.getString("name"));
	                dto.setDescription(rs.getString("description"));
	                dto.setStock(rs.getInt("stock"));
	                dto.setPrice(rs.getInt("price"));		//��.�߰�
	                dto.setReg_date(rs.getDate("reg_date"));

	                list.add(dto);
	            }

	            rs.close();
	            pstmt.close();

	        } catch (Exception e) {
	            System.out.println("getAllProducts ����: " + e.toString());
	        }

	        return list;
	    }

	    // 5. ��ǰ �ϳ��� �˻� (��ǰ��ȣ��)
	    public ProductDTO getProductById(int product_id) {
	        ProductDTO dto = null;

	        Connection conn = DBConn.getConnection();
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	        String sql;

	        try {
	        	//��.sql�� ����
		        sql = "SELECT P.product_id, P.name, P.description, P.stock, P.price, P.reg_date, " ;
		        sql += "NVL(D.discount_rate, 0) AS discount_rate ";
		        sql += "FROM PRODUCT P LEFT JOIN DISCOUNT D ";
		        sql += "ON P.product_id = D.product_id where P.product_id = ?";

	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, product_id);

	            rs = pstmt.executeQuery();

	            if (rs.next()) {
	                dto = new ProductDTO();

	                dto.setProduct_id(rs.getInt("product_id"));
	                dto.setName(rs.getString("name"));
	                dto.setDescription(rs.getString("description"));
	                dto.setStock(rs.getInt("stock"));
	                dto.setPrice(rs.getInt("price"));	//��.�߰�
	                dto.setReg_date(rs.getDate("reg_date"));
	                dto.setDiscountRate(rs.getInt("discount_rate"));	//��.�߰�
	                int discountedPrice = (int) (dto.getPrice() * ((100 - dto.getDiscountRate()) / 100.0));		//��.�߰�
	                dto.setDiscountedPrice(discountedPrice);		//��.�߰�
	            }

	            rs.close();
	            pstmt.close();

	        } catch (Exception e) {
	            System.out.println("getProductById ����: " + e.toString());
	        }

	        return dto;
	    }
	    
	    public List<ProductDTO> getDiscountedProductList() {
	        List<ProductDTO> list = new ArrayList<>();

	        Connection conn = DBConn.getConnection();
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;

	        String sql = "SELECT P.product_id, P.name, P.description, P.stock, P.reg_date, P.price, " ;
	        sql += "NVL(D.discount_rate, 0) AS discount_rate ";
	        sql += "FROM PRODUCT P LEFT JOIN DISCOUNT D ";
	        sql += "ON P.product_id = D.product_id";

	        try {
	            pstmt = conn.prepareStatement(sql);
	            rs = pstmt.executeQuery();

	            while (rs.next()) {
	                ProductDTO dto = new ProductDTO();

	                dto.setProduct_id(rs.getInt("product_id"));
	                dto.setName(rs.getString("name"));
	                dto.setDescription(rs.getString("description"));
	                dto.setStock(rs.getInt("stock"));
	                dto.setReg_date(rs.getDate("reg_date"));
	                dto.setPrice(rs.getInt("price"));
	                dto.setDiscountRate(rs.getInt("discount_rate"));  // ������ �߰�
	                int discountedPrice = (int) (dto.getPrice() * ((100 - dto.getDiscountRate()) / 100.0));
	                dto.setDiscountedPrice(discountedPrice);
	                
	                
	                list.add(dto);
	            }

	            rs.close();
	            pstmt.close();

	        } catch (Exception e) {
	            System.out.println(e.toString());
	        }

	        return list;
	    }
	    
	}

